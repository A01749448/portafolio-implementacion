import json
import random
import requests

def lambda_handler(event, context):

    intent_name = event['interpretations'][0]['intent']['name']
    slots = event['interpretations'][0]['intent']['slots']
    costoComida = slots['costoComida']['value']['interpretedValue']
    costoBebida = slots['costoBebida']['value']['interpretedValue']
    costoPostre = slots['costoPostre']['value']['interpretedValue']
    precio = int(costoComida) + int(costoBebida) + int(costoPostre)
    message = "El precio de tu pedido es de $" + str(precio)
    

    response = {
       'sessionState' : {
            'dialogAction' : {
                'type' : 'Close'
            },
            'intent' : {
                'name' : intent_name,
                'state' : 'Fulfilled'
            }
       },
        'messages': [
             {
                'contentType' : 'PlainText',
                'content' : message
             }
        ]
    }

    return response